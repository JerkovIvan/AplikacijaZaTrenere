<?php
header("Access-Control-Allow-Origin: *"); 
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

header('Content-Type: application/json');

include __DIR__ . '/../db/db_connection.php';

$data = json_decode(file_get_contents("php://input"));

if (!isset($data->access_code, $data->user_name, $data->user_phone, $data->date, $data->start_time, $data->duration, $data->type)) {
    echo json_encode(["error" => "Nedostaju podaci"]);
    exit;
}

$access_code = $data->access_code;
$query = "SELECT * FROM trainers WHERE access_code = :access_code";
$stmt = $conn->prepare($query);
$stmt->bindParam(':access_code', $access_code);
$stmt->execute();
$trainer = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$trainer) {
    echo json_encode(["error" => "Nevalidan access_code"]);
    exit;
}

$user_name = trim($data->user_name);
$user_phone = trim($data->user_phone);
$date = $data->date;
$start_time = $data->start_time;
$duration = (int)$data->duration;
$type = $data->type;


// Datum format YYYY-MM-DD
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    echo json_encode(["error" => "Nevalidan format datuma (potreban YYYY-MM-DD)"]);
    exit;
}

// Vreme format HH:MM
if (!preg_match('/^\d{2}:\d{2}$/', $start_time)) {
    echo json_encode(["error" => "Nevalidan format vremena (potreban HH:MM)"]);
    exit;
}

// Trajanje samo 30 ili 60 min
if ($duration !== 30 && $duration !== 60) {
    echo json_encode(["error" => "Trajanje treninga mora biti 30 ili 60 minuta"]);
    exit;
}

// Vreme mora biti na pola sata
$minute = (int)explode(':', $start_time)[1];
if ($minute !== 0 && $minute !== 30) {
    echo json_encode(["error" => "Vreme početka treninga mora biti na pola sata (npr. 9:00 ili 9:30)"]);
    exit;
}

// Provera da termin nije u prošlosti
$trainingDateTime = DateTime::createFromFormat('Y-m-d H:i', "$date $start_time");
$now = new DateTime();

if (!$trainingDateTime) {
    echo json_encode(["error" => "Nevalidan datum i vreme"]);
    exit;
}

if ($trainingDateTime < $now) {
    echo json_encode(["error" => "Termin ne može biti u prošlosti"]);
    exit;
}

// Provera da li postoji konflikt termina kod istog trenera
$query = "
SELECT * FROM trainings 
WHERE trainer_id = :trainer_id 
AND date = :date 
AND status = 'scheduled'
AND (
    (start_time <= :start_time AND ADDTIME(start_time, SEC_TO_TIME(duration*60)) > :start_time)
    OR
    (start_time < ADDTIME(:start_time, SEC_TO_TIME(:duration*60)) AND ADDTIME(start_time, SEC_TO_TIME(duration*60)) >= ADDTIME(:start_time, SEC_TO_TIME(:duration*60)))
    OR
    (start_time >= :start_time AND ADDTIME(start_time, SEC_TO_TIME(duration*60)) <= ADDTIME(:start_time, SEC_TO_TIME(:duration*60)))
)";

$stmt = $conn->prepare($query);
$stmt->bindParam(':trainer_id', $trainer['id']);
$stmt->bindParam(':date', $date);
$stmt->bindParam(':start_time', $start_time);
$stmt->bindParam(':duration', $duration);
$stmt->execute();

if ($stmt->fetch(PDO::FETCH_ASSOC)) {
    echo json_encode(["error" => "Termin je zauzet u ovom periodu"]);
    exit;
}

// Provera i/ili dodavanje korisnika po telefonu
$query = "SELECT * FROM users WHERE phone = :phone";
$stmt = $conn->prepare($query);
$stmt->bindParam(':phone', $user_phone);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    $query = "INSERT INTO users (name, phone) VALUES (:name, :phone)";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':name', $user_name);
    $stmt->bindParam(':phone', $user_phone);
    $stmt->execute();
    $user_id = $conn->lastInsertId();
} else {
    $user_id = $user['id'];
}

// Ubacivanje novog treninga
$query = "INSERT INTO trainings (trainer_id, user_id, date, start_time, duration, type, status) 
          VALUES (:trainer_id, :user_id, :date, :start_time, :duration, :type, 'scheduled')";
$stmt = $conn->prepare($query);
$stmt->bindParam(':trainer_id', $trainer['id']);
$stmt->bindParam(':user_id', $user_id);
$stmt->bindParam(':date', $date);
$stmt->bindParam(':start_time', $start_time);
$stmt->bindParam(':duration', $duration);
$stmt->bindParam(':type', $type);
$stmt->execute();

echo json_encode([
    "success" => "Trening zakazan!",
    "training_id" => $conn->lastInsertId()
]);
