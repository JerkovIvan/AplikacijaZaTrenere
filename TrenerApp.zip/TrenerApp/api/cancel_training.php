<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}
header('Content-Type: application/json');
include __DIR__ . '/../db/db_connection.php';

$cancellationDeadline = 24; 

$data = json_decode(file_get_contents("php://input"));

// Proveravamo da li imamo potrebne podatke
if (!isset($data->access_code, $data->training_id)) {
    echo json_encode(["error" => "Nedostaju podaci: access_code i training_id su obavezni"]);
    exit;
}

$access_code = $data->access_code;
$training_id = $data->training_id;

// Provera da li trener sa datim access_code postoji
$query = "SELECT * FROM trainers WHERE access_code = :access_code";
$stmt = $conn->prepare($query);
$stmt->bindParam(':access_code', $access_code);
$stmt->execute();
$trainer = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$trainer) {
    echo json_encode(["error" => "Nevalidan access_code"]);
    exit;
}

// da li postoji trening sa tim id-jem i da li je zakazan
$query = "SELECT * FROM trainings WHERE id = :training_id AND status = 'scheduled' AND trainer_id = :trainer_id";
$stmt = $conn->prepare($query);
$stmt->bindParam(':training_id', $training_id);
$stmt->bindParam(':trainer_id', $trainer['id']);
$stmt->execute();

$training = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$training) {
    echo json_encode(["error" => "Trening ne postoji, nije zakazan ili ne pripada ovom treneru"]);
    exit;
}

// Provera da li je moguće otkazati trening
$trainingDateTime = new DateTime($training['date'] . ' ' . $training['start_time']);
$now = new DateTime();

$deadline = clone $trainingDateTime;
$deadline->modify("-{$cancellationDeadline} hours");

if ($now > $deadline) {
    echo json_encode(["error" => "Trening se može otkazati najkasnije {$cancellationDeadline}h pre početka"]);
    exit;
}


// Otkazivanje treninga
$updateQuery = "UPDATE trainings SET status = 'cancelled' WHERE id = :training_id";
$updateStmt = $conn->prepare($updateQuery);
$updateStmt->bindParam(':training_id', $training_id);
$updateStmt->execute();

echo json_encode(["success" => "Trening uspešno otkazan"]);
?>
