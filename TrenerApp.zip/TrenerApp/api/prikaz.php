<?php
include __DIR__ . '/../db/db_connection.php';

function timeToMinutes($time) {
    list($h, $m) = explode(':', $time);
    return $h * 60 + $m;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['add_training'])) {
        $user_name = trim($_POST['name']);
        $user_phone = trim($_POST['phone']);
        $date = $_POST['date'];
        $start_time = $_POST['start_time'];
        $duration = (int)$_POST['duration'];
        $type = $_POST['type'];
        $status = "scheduled";
        $trainer_id = $_POST['trainer_id'];

        // Provera preklapanja termina za istog trenera na datom datumu
        $new_start = timeToMinutes($start_time);
        $new_end = $new_start + $duration;

        $stmt = $conn->prepare("
            SELECT start_time, duration 
            FROM trainings 
            WHERE date = :date AND trainer_id = :trainer_id AND status = 'scheduled'
        ");
        $stmt->bindParam(':date', $date);
        $stmt->bindParam(':trainer_id', $trainer_id);
        $stmt->execute();
        $existing_trainings = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $conflict = false;
        foreach ($existing_trainings as $training) {
            $exist_start = timeToMinutes($training['start_time']);
            $exist_end = $exist_start + (int)$training['duration'];

            // Provera da li se termini preklapaju
            if (!($new_end <= $exist_start || $new_start >= $exist_end)) {
                $conflict = true;
                break;
            }
        }

        if ($conflict) {
            echo "<p style='color: red;'>Greška: Termin se preklapa sa već zakazanim treningom za izabranog trenera.</p>";
        } else {
            // Provera da li korisnik postoji
            $stmt = $conn->prepare("SELECT id FROM users WHERE phone = :phone");
            $stmt->bindParam(':phone', $user_phone);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                $stmt = $conn->prepare("INSERT INTO users (name, phone) VALUES (:name, :phone)");
                $stmt->bindParam(':name', $user_name);
                $stmt->bindParam(':phone', $user_phone);
                $stmt->execute();
                $user_id = $conn->lastInsertId();
            } else {
                $user_id = $user['id'];
            }

            $stmt = $conn->prepare("INSERT INTO trainings (user_id, date, start_time, duration, type, status, trainer_id)
                                    VALUES (:user_id, :date, :start_time, :duration, :type, :status, :trainer_id)");
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':date', $date);
            $stmt->bindParam(':start_time', $start_time);
            $stmt->bindParam(':duration', $duration);
            $stmt->bindParam(':type', $type);
            $stmt->bindParam(':status', $status);
            $stmt->bindParam(':trainer_id', $trainer_id);
            $stmt->execute();

            echo "<p style='color: green;'>Trening je uspešno dodat!</p>";
        }
    }

    if (isset($_POST['cancel_id'])) {
        $cancelId = $_POST['cancel_id'];
        $stmt = $conn->prepare("UPDATE trainings SET status = 'cancelled' WHERE id = :id");
        $stmt->bindParam(':id', $cancelId);
        $stmt->execute();
        echo "<p style='color: orange;'>Trening ID $cancelId je otkazan.</p>";
    }

    if (isset($_POST['delete_id'])) {
        $deleteId = $_POST['delete_id'];
        $stmt = $conn->prepare("DELETE FROM trainings WHERE id = :id");
        $stmt->bindParam(':id', $deleteId);
        $stmt->execute();
        echo "<p style='color: red;'>Trening ID $deleteId je obrisan.</p>";
    }
}

$query = "
    SELECT t.id, u.name AS user_name, u.phone, t.date, t.start_time, t.duration, t.type, t.status, tr.name AS trainer_name
    FROM trainings t
    JOIN users u ON t.user_id = u.id
    JOIN trainers tr ON t.trainer_id = tr.id
    ORDER BY t.date, t.start_time
";
$stmt = $conn->prepare($query);
$stmt->execute();
$trainings = $stmt->fetchAll(PDO::FETCH_ASSOC);

$trainers = $conn->query("SELECT id, name FROM trainers")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <title>Zakazivanje i Prikaz Treninga</title>
    <style>
        body {
            font-family: Arial;
            margin: 20px;
            background-color: #2c2c2c;
            color: white;
            position: relative;
        }

        .logout-button {
            top: 20px;
            right: 20px;
            background-color: #ff6600;
            color: white;
            border: none;
            padding: 10px 15px;
            font-weight: 600;
            border-radius: 5px;
            cursor: pointer;
            z-index: 1000;
            transition: background-color 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .logout-button:hover {
            background-color: #e65c00;
        }

        .form-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        form {
            margin-bottom: 30px;
            padding: 15px;
            width: 500px;
            background-color: #2c2c2c;
            border-radius: 8px;
        }

        label {
            display: block;
            margin-top: 10px;
            font-weight: 600;
        }

        input, select, button {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1.5px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            background-color: #ff6600;
            color: white;
            font-weight: 600;
            border: none;
            cursor: pointer;
            margin-top: 15px;
        }

        button:hover {
            background-color: #e65c00;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
        }

        th, td {
            padding: 10px;
            border: 1px solid #aaa;
            text-align: center;
        }

        th {
            background-color: #e65c00;
        }

        .delete-btn {
            background-color: red;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            font-weight: 600;
        }

        .delete-btn:hover {
            background-color: darkred;
        }

        .cancel-btn {
            background-color: orange;
            color: white;
            border: none;
            cursor: pointer;
            margin-right: 5px;
            border-radius: 4px;
            font-weight: 600;
        }

        .cancel-btn:hover {
            background-color: darkorange;
        }

    </style>
</head>
<body>

<a href="trener-pristup.php" class="logout-button">Odjavi se</a>

<div class="form-container">
    <h2>Dodaj novi trening</h2>
    <form method="post">
        <input type="hidden" name="add_training" value="1">

        <label for="name">Ime i prezime:</label>
        <input type="text" name="name" required>

        <label for="phone">Telefon:</label>
        <input type="tel" name="phone" required>

        <label for="date">Datum:</label>
        <input type="date" name="date" required>

        <label for="start_time">Vreme:</label>
        <select name="start_time" required>
            <option value="">Izaberite vreme</option>
            <option value="09:00">09:00</option>
            <option value="09:30">09:30</option>
            <option value="10:00">10:00</option>
            <option value="10:30">10:30</option>
            <option value="11:00">11:00</option>
            <option value="11:30">11:30</option>
            <option value="12:00">12:00</option>
            <option value="12:30">12:30</option>
            <option value="13:00">13:00</option>
            <option value="13:30">13:30</option>
            <option value="14:00">14:00</option>
            <option value="14:30">14:30</option>
            <option value="15:00">15:00</option>
            <option value="15:30">15:30</option>
            <option value="16:00">16:00</option>
            <option value="16:30">16:30</option>
            <option value="17:00">17:00</option>
            <option value="17:30">17:30</option>
            <option value="18:00">18:00</option>
            <option value="18:30">18:30</option>
            <option value="19:00">19:00</option>
            <option value="19:30">19:30</option>
            <option value="20:00">20:00</option>
            <option value="20:30">20:30</option>
            <option value="21:00">21:00</option>
        </select>

        <label for="duration">Trajanje (min):</label>
        <select name="duration" required>
            <option value="30">30</option>
            <option value="60">60</option>
        </select>

        <label for="type">Tip treninga:</label>
        <select name="type">
            <option value="fitness">Fitness</option>
            <option value="yoga">Yoga</option>
            <option value="pilates">Pilates</option>
            <option value="crossfit">CrossFit</option>
        </select>

        <label for="trainer_id">Trener:</label>
        <select name="trainer_id" required>
            <option value="">Izaberite trenera</option>
            <?php foreach ($trainers as $trainer): ?>
                <option value="<?= htmlspecialchars($trainer['id']) ?>"><?= htmlspecialchars($trainer['name']) ?></option>
            <?php endforeach; ?>
        </select>

        <button type="submit">Dodaj trening</button>
    </form>
</div>

<h2>Zakazani treninzi</h2>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Korisnik</th>
            <th>Telefon</th>
            <th>Datum</th>
            <th>Vreme</th>
            <th>Trajanje (min)</th>
            <th>Tip</th>
            <th>Status</th>
            <th>Trener</th>
            <th>Akcije</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($trainings as $t): ?>
        <tr>
            <td><?= htmlspecialchars($t['id']) ?></td>
            <td><?= htmlspecialchars($t['user_name']) ?></td>
            <td><?= htmlspecialchars($t['phone']) ?></td>
            <td><?= htmlspecialchars($t['date']) ?></td>
            <td><?= htmlspecialchars($t['start_time']) ?></td>
            <td><?= htmlspecialchars($t['duration']) ?></td>
            <td><?= htmlspecialchars($t['type']) ?></td>
            <td><?= htmlspecialchars($t['status']) ?></td>
            <td><?= htmlspecialchars($t['trainer_name']) ?></td>
            <td>
                <?php if ($t['status'] == 'scheduled'): ?>
                    <form method="post" style="display:inline-block;">
                        <input type="hidden" name="cancel_id" value="<?= $t['id'] ?>">
                        <button type="submit" class="cancel-btn" onclick="return confirm('Da li ste sigurni da želite otkazati trening?')">Otkazi</button>
                    </form>
                <?php endif; ?>
                <form method="post" style="display:inline-block;">
                    <input type="hidden" name="delete_id" value="<?= $t['id'] ?>">
                    <button type="submit" class="delete-btn" onclick="return confirm('Da li ste sigurni da želite obrisati trening?')">Obrisi</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

</body>
</html>
