<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <title>Pristup za trenere</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
    font-family: Arial, sans-serif;
    padding: 30px;
    background-color: #1e1e1e;
}


        .form-container {
            max-width: 400px;
            margin: 100px auto;
            padding: 30px;
            background: white;
            border-radius: 10px;
            
        }

        .form-container h2 {
            text-align: center;
        }

        .form-container input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-top: 15px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-container button {
            width: 100%;
            background-color: #ff6600;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        .form-container button:hover {
            background-color: #e65c00;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Pristup za trenere</h2>
    <form method="POST" action="prikaz.php">
        <label for="kod">Unesite jedinstveni kod:</label>
        <input type="text" name="kod" id="kod" required>
        <button type="submit">Prijavi se kao trener</button>
    </form>
    <form action="/TrenerApp/frontend/index.php" method="get" style="margin-top: 10px;">
        <button type="submit">Nazad na početnu</button>
    </form>
</div>

</body>
</html>
