<!DOCTYPE html>
<html lang="sr">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?php echo "Simple Gym"; ?></title>
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <header>
        <h1><?php echo "SIMPLE GYM"; ?></h1>
    </header>

    <main class="split-section">
        <div class="left-side">
            <p>Dobrodošli u Simple Gym – Vašu destinaciju za vrhunski trening!</p>
            <p>Simple Gym je teretana opremljena najboljim spravama i modernom opremom koja vam omogućava da ostvarite svoje fitnes
                ciljeve brzo i efikasno. Bilo da ste početnik ili profesionalac, ovde ćete pronaći sve što vam treba – od sprava za
                snagu, kardio mašina, do prostora za funkcionalni trening.</p>
            <p>Naš trener Marko je pravi stručnjak sa dugogodišnjim iskustvom i individualnim pristupom. Posvećen je vašem napretku i
                zdravlju i garantuje da će svaki trening biti efektivan, bezbedan i motivišući.</p>
            <p>Pridružite nam se i otkrijte zašto je Simple Gym najbolji izbor za vaš fitnes put!</p>
            <a href="zakazi.php" id="btnZakazi">ZAKAŽI TRENING</a>
        </div>

        <div class="right-side">
            <img src="trener.jpg" />
            <form action="/TrenerApp/api/trener-pristup.php" method="post">
                <button id="btnTrener" type="submit">PRISTUP TRENERA</button>
            </form>
        </div>
    </main>
</body>

</html>
