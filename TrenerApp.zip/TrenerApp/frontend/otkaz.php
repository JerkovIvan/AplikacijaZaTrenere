<!DOCTYPE html>
<html lang="sr">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Simple Gym - Otkaži Trening</title>
    <link rel="stylesheet" href="otkaz.css" />
</head>

<body>
    <header>
        <h1>Otkaži Trening</h1>
    </header>

    <div class="form-wrapper">
        <div class="form-container">
            <form id="cancelForm">
                <label for="training_id">ID Treninga:</label>
                <input type="number" id="training_id" name="training_id" required />

                <button type="submit">Otkaži trening</button>
                <button type="button" onclick="window.location.href='index.php'" class="form-button" style="margin-top: 15px;">Nazad na početnu</button>
            </form>

            <div id="responseMessage"></div>
        </div>
    </div>

    <script>
        const accessCode = 'abc123';

        const form = document.getElementById('cancelForm');
        const responseDiv = document.getElementById('responseMessage');

        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            const data = {
                access_code: accessCode,
                training_id: parseInt(document.getElementById('training_id').value, 10)
            };

            try {
                const response = await fetch('http://localhost/TrenerApp/api/cancel_training.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data),
                });

                const result = await response.json();

                if (result.error) {
                    responseDiv.textContent = 'Greška: ' + result.error;
                    responseDiv.style.color = 'red';
                } else if (result.success) {
                    responseDiv.textContent = result.success;
                    responseDiv.style.color = 'green';
                    form.reset();
                }
            } catch (error) {
                responseDiv.textContent = 'Greška u komunikaciji sa serverom.';
                responseDiv.style.color = 'red';
            }
        });
    </script>
</body>

</html>
