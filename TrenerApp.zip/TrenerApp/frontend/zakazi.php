<!DOCTYPE html>
<html lang="sr">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?php echo "Simple Gym - Zakazivanje"; ?></title>
    <link rel="stylesheet" href="zakazi.css" />
</head>

<body>
    <header>
        <h1><?php echo "Simple Gym"; ?></h1>
    </header>

    <div class="form-wrapper">
        <div class="form-container">
            <form id="bookingForm">
                <label for="name">Ime i prezime:</label>
                <input type="text" id="name" name="name" required />

                <label for="phone">Telefon:</label>
                <input type="tel" id="phone" name="phone" required />

                <label for="date">Datum treninga:</label>
                <input type="date" id="date" name="date" required />

                <label for="type">Tip treninga:</label>
                <select id="type" name="type">
                    <option value="fitness">Fitness</option>
                    <option value="yoga">Yoga</option>
                    <option value="pilates">Pilates</option>
                    <option value="crossfit">CrossFit</option>
                </select>

                <label for="start_time">Vreme treninga:</label>
                <select id="start_time" name="start_time" required>
                    <option value="">Izaberite vreme</option>
                    <option value="09:00">09:00</option>
                    <option value="09:30">09:30</option>
                    <option value="10:00">10:00</option>
                    <option value="10:30">10:30</option>
                    <option value="11:00">11:00</option>
                    <option value="11:30">11:30</option>
                    <option value="12:00">12:00</option>
                    <option value="12:30">12:30</option>
                    <option value="13:00">13:00</option>
                    <option value="13:30">13:30</option>
                    <option value="14:00">14:00</option>
                    <option value="14:30">14:30</option>
                    <option value="15:00">15:00</option>
                    <option value="15:30">15:30</option>
                    <option value="16:00">16:00</option>
                    <option value="16:30">16:30</option>
                    <option value="17:00">17:00</option>
                    <option value="17:30">17:30</option>
                    <option value="18:00">18:00</option>
                    <option value="18:30">18:30</option>
                    <option value="19:00">19:00</option>
                    <option value="19:30">19:30</option>
                    <option value="20:00">20:00</option>
                    <option value="20:30">20:30</option>
                    <option value="21:00">21:00</option>
                    

                </select>

                <label for="duration">Trajanje treninga (min):</label>
                <select id="duration" name="duration" required>
                    <option value="">Izaberite trajanje</option>
                    <option value="30">30</option>
                    <option value="60">60</option>
                </select>

                <input type="hidden" id="access_code" name="access_code" value="abc123" />

                <button type="submit" class="form-button">Zakaži trening</button>
            </form>

            <button type="button" onclick="window.location.href='otkaz.php'" class="form-button">Otkaži trening</button>
            <button type="button" onclick="history.back()" class="form-button">Nazad</button>

            <div id="responseMessage"></div>
        </div>
    </div>

    <script>
        const form = document.getElementById('bookingForm');
        const responseDiv = document.getElementById('responseMessage');

        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            const data = {
                access_code: document.getElementById('access_code').value,
                user_name: document.getElementById('name').value,
                user_phone: document.getElementById('phone').value,
                date: document.getElementById('date').value,
                start_time: document.getElementById('start_time').value,
                duration: document.getElementById('duration').value,
                type: document.getElementById('type').value
            };

            try {
                const response = await fetch('http://localhost/TrenerApp/api/book_training.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data),
                });

                const result = await response.json();

                if (result.error) {
                    responseDiv.textContent = 'Greška: ' + result.error;
                    responseDiv.style.color = 'red';
                } else if (result.success) {
                    responseDiv.innerHTML = `${result.success} <br> <strong>Vaš ID treninga je:</strong> ${result.training_id} <br> Sačuvajte ga za eventualno otkazivanje.`;
                    responseDiv.style.color = 'green';
                    form.reset();
                }
            } catch (error) {
                responseDiv.textContent = 'Greška u komunikaciji sa serverom.';
                responseDiv.style.color = 'red';
            }
        });
    </script>
</body>

</html>
